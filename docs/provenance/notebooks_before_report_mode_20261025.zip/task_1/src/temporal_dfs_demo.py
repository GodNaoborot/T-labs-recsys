"""Маленькая проверка временных возможностей Featuretools без обучения моделей."""
import warnings

import featuretools as ft
import numpy as np
import pandas as pd
from featuretools.primitives import Count, TimeSinceLast
from woodwork.logical_types import Datetime, Double, Integer


ORIGIN = pd.Timestamp('2000-01-01')  # Условная точка отсчета, не даты Yambda.


def example_history():
    """История с событиями на обеих границах окон и незавершенным прослушиванием."""
    history = pd.DataFrame({
        'log_id': range(9),
        'uid': [1] * 8 + [3],
        'start_day': [-1, 9, 11, 12, 17, 19, 19, 19, 4],
        'end_day': [0, 10, 12, 13, 18, 20, 20, 21, 5],
        'label': [0., 1., 2., 0., 2., 0., 1., 2., 1.],
    })
    history['start_ts'] = ORIGIN + pd.to_timedelta(history.pop('start_day'), unit='D')
    history['end_ts'] = ORIGIN + pd.to_timedelta(history.pop('end_day'), unit='D')
    return history


def make_entityset(history):
    """Связать пользователей с событиями; доступность задается временем окончания."""
    entityset = ft.EntitySet(id='temporal_demo')
    users = pd.DataFrame({'uid': [1, 2, 3]})  # У пользователя 2 истории нет.
    entityset.add_dataframe(
        dataframe_name='Users', dataframe=users, index='uid',
        logical_types={'uid': Integer})
    entityset.add_dataframe(
        dataframe_name='Interactions', dataframe=history.copy(), index='log_id',
        time_index='end_ts', logical_types={
            'log_id': Integer, 'uid': Integer, 'label': Double,
            'start_ts': Datetime, 'end_ts': Datetime})
    entityset.add_relationship('Users', 'uid', 'Interactions', 'uid')
    entityset.add_last_time_indexes()
    return entityset


def make_features(entityset, *, seed_features=None):
    """DFS составляет агрегаты и, при наличии оконных заготовок, их произведения."""
    return ft.dfs(
        entityset=entityset, target_dataframe_name='Users', features_only=True,
        agg_primitives=['count', 'mean', TimeSinceLast(unit='days')],
        trans_primitives=['multiply_numeric'] if seed_features else [],
        seed_features=seed_features, max_depth=2 if seed_features else 1,
        ignore_columns={'Interactions': ['start_ts']})


def calculate(features, entityset, cutoffs, window=None):
    """Посчитать признаки по end_ts < cutoff; окно ограничивает и нижнюю границу."""
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=FutureWarning, module='featuretools.*')
        return ft.calculate_feature_matrix(
            features=features, entityset=entityset, cutoff_time=cutoffs,
            cutoff_time_in_index=True, training_window=window,
            include_cutoff_time=False, n_jobs=1)


def expected_values(history, uid, cutoff, window=None):
    """Независимый ответ через фильтрацию строк pandas, без Featuretools."""
    selected = history.loc[(history['uid'] == uid) & (history['end_ts'] < cutoff)]
    if window is not None:
        selected = selected.loc[selected['end_ts'] >= cutoff - pd.Timedelta(window)]
    count = len(selected)
    mean = selected['label'].mean()
    recency = (cutoff - selected['end_ts'].max()) / pd.Timedelta(days=1)
    return [count, mean, recency]


def check_matrix(matrix, history, names, window=None):
    """Сверить счетчик, среднюю метку и свежесть во всех строках с ответом pandas."""
    columns = [names[name] for name in ['count', 'mean', 'time_since_last']]
    expected = [expected_values(history, uid, cutoff, window)
                for uid, cutoff in matrix.index]
    np.testing.assert_allclose(matrix[columns].to_numpy(dtype=float), expected,
                               rtol=1e-12, atol=1e-12, equal_nan=True)


def run_temporal_checks():
    """Проверить окна, свежесть, границы и независимость от неизвестного будущего."""
    history = example_history()
    cutoff = ORIGIN + pd.Timedelta(days=20)
    cutoffs = pd.DataFrame({'uid': [1, 2, 3], 'time': [cutoff] * 3})
    entityset = make_entityset(history)
    features = make_features(entityset)
    names = {feature.primitive.name: feature.get_name() for feature in features}
    rows = []

    # Изменяем только исходы еще недоступных событий. Они не должны влиять на ответ.
    changed = history.copy()
    changed.loc[changed['end_ts'] >= cutoff, 'label'] = 999.
    changed_entityset = make_entityset(changed)
    for window in [None, '7 days', '10 days']:
        matrix = calculate(features, entityset, cutoffs, window)
        check_matrix(matrix, history, names, window)
        again = calculate(features, changed_entityset, cutoffs, window)
        pd.testing.assert_frame_equal(matrix, again)
        for (uid, time), values in matrix.iterrows():
            rows.append({'uid': uid, 'window': window or 'all history',
                         'count': values[names['count']],
                         'mean_label': values[names['mean']],
                         'recency_days': values[names['time_since_last']]})

    # После окончания события становятся доступны: на секунду позже счетчик растет.
    later = cutoffs.copy()
    later['time'] += pd.Timedelta(seconds=1)
    later_matrix = calculate(features, entityset, later)
    check_matrix(later_matrix, history, names)
    assert later_matrix.loc[(1, cutoff + pd.Timedelta(seconds=1)), names['count']] == 7

    # use_previous задает окно отдельной формулы; оба окна живут в одной матрице.
    window_features = [ft.AggregationFeature(
        entityset['Interactions'].ww['log_id'], parent_dataframe_name='Users',
        primitive=Count(), use_previous=f'{days} days') for days in [7, 10]]
    combined_features = make_features(entityset, seed_features=window_features)
    combined = calculate(combined_features, entityset, cutoffs)
    for feature, window in zip(window_features, ['7 days', '10 days']):
        expected = [expected_values(history, uid, time, window)[0]
                    for uid, time in combined.index]
        np.testing.assert_allclose(combined[feature.get_name()], expected)
    # Свежесть по всей истории сохраняется даже при нулевых оконных счетчиках.
    check_matrix(combined, history, names)
    seed_names = [feature.get_name() for feature in window_features]
    products = [feature for feature in combined_features
                if feature.primitive.name == 'multiply_numeric'
                and all(name in feature.get_name() for name in seed_names)]
    assert products, 'DFS должен составить произведение двух оконных счетчиков'
    expected_product = combined[seed_names[0]] * combined[seed_names[1]]
    np.testing.assert_allclose(combined[products[0].get_name()], expected_product)
    pd.testing.assert_frame_equal(
        combined, calculate(combined_features, changed_entityset, cutoffs))
    selected = seed_names + [names['time_since_last']]
    return {'featuretools_version': ft.__version__,
            'global_windows': pd.DataFrame(rows),
            'combined_windows': combined[selected],
            'generated_formulas': [feature.get_name() for feature in combined_features],
            'checks': 'passed'}


if __name__ == '__main__':
    result = run_temporal_checks()
    print('Featuretools:', result['featuretools_version'])
    print(result['global_windows'].to_string(index=False))
    print(result['combined_windows'].to_string())
    print('Проверки границ, pandas-эталона и будущих меток:', result['checks'])
